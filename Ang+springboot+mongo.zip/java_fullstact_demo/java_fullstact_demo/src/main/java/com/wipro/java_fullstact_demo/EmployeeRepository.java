package com.wipro.java_fullstact_demo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

public interface EmployeeRepository extends MongoRepository<Employee,Long> {

}
