package com.wipro.java_fullstact_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaFullstactDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaFullstactDemoApplication.class, args);
	}

}
