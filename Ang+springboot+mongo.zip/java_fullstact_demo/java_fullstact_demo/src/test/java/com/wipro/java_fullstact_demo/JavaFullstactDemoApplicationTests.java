package com.wipro.java_fullstact_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaFullstactDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
